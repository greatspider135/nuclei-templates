|    TAG    | COUNT |    AUTHOR     | COUNT |    DIRECTORY     | COUNT | SEVERITY | COUNT |  TYPE   | COUNT |
|-----------|-------|---------------|-------|------------------|-------|----------|-------|---------|-------|
| cve       |   833 | daffainfo     |   288 | cves             |   837 | info     |   749 | http    |  2211 |
| lfi       |   342 | pikpikcu      |   281 | vulnerabilities  |   327 | high     |   649 | file    |    50 |
| panel     |   272 | dhiyaneshdk   |   279 | exposed-panels   |   269 | medium   |   476 | network |    45 |
| xss       |   258 | pdteam        |   201 | technologies     |   201 | critical |   294 | dns     |    12 |
| wordpress |   252 | geeknik       |   162 | exposures        |   191 | low      |   155 |         |       |
| exposure  |   240 | dwisiswant0   |   131 | misconfiguration |   141 |          |       |         |       |
| rce       |   214 | gy741         |    81 | takeovers        |    65 |          |       |         |       |
| tech      |   196 | pussycat0x    |    72 | token-spray      |    63 |          |       |         |       |
| wp-plugin |   175 | princechaddha |    66 | default-logins   |    60 |          |       |         |       |
| cve2020   |   165 | madrobot      |    63 | file             |    50 |          |       |         |       |
